#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import webapp2
import os
import logging
import jinja2

# Lets set it up so we know where we stored the template files
JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
    extensions=['jinja2.ext.autoescape'],
    autoescape=True)

class IndexHandler(webapp2.RequestHandler):
    def get(self):
    	template = JINJA_ENVIRONMENT.get_template('templates/index.html')
    	self.response.write(template.render({'title': 'HOME'}))

class WorkHandler(webapp2.RequestHandler):
    def get(self):
    	template = JINJA_ENVIRONMENT.get_template('templates/work.html')
    	self.response.write(template.render({'title': 'WORK'}))

class BioHandler(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('templates/bio.html')
        self.response.write(template.render({'title': 'BIO'}))

class CVHandler(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('templates/cv.html')
        self.response.write(template.render({'title': 'CV'}))


class LoginHandler(webapp2.RequestHandler):
    def get(self):
    	template = JINJA_ENVIRONMENT.get_template('templates/login.html')
        self.response.write(template.render({'title': 'LOGIN'}))

    def post(self):
        error = 'Bad credentials. Try again.'
        name = self.request.get('name')
        answer = 'Colleen'  
        pw = self.request.get('pw')
        answer2 = 'pass'
        
        if name == answer and pw == answer2:
            template = JINJA_ENVIRONMENT.get_template('templates/loginsuccess.html')
            self.response.write(template.render({'title': 'LOGIN'}))

        else:
            template = JINJA_ENVIRONMENT.get_template('templates/login.html')
            self.response.write(template.render({'title': 'LOGIN', 'error': error}))
            logging.info("%s %s", name, pw)


app = webapp2.WSGIApplication([
    ('/', IndexHandler),
    ('/index.html', IndexHandler),
    ('/work.html', WorkHandler),
    ('/bio.html', BioHandler),
    ('/cv.html', CVHandler),
    ('/login.html', LoginHandler)
], debug=True)
